var searchData=
[
  ['alpha',['alpha',['../class_basic_gaussian_process.html#a4c7dc27e69651a7850681a6a5c044317',1,'BasicGaussianProcess']]]
];
