var searchData=
[
  ['kriging',['Kriging',['../class_kriging.html',1,'Kriging'],['../class_kriging.html#a6dabe7df003209bca307ddede11796cf',1,'Kriging::Kriging()']]],
  ['kriging_2em',['Kriging.m',['../_kriging_8m.html',1,'']]]
];
