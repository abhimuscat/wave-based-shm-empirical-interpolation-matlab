var searchData=
[
  ['updatemodel',['updateModel',['../class_basic_gaussian_process.html#ab0b273aed79e41eb3b96df1ecdc761bf',1,'BasicGaussianProcess']]],
  ['updateregression',['updateRegression',['../class_basic_gaussian_process.html#a05379f1addc3495b113848b2a64be11b',1,'BasicGaussianProcess']]],
  ['updatestochasticprocess',['updateStochasticProcess',['../class_basic_gaussian_process.html#a180189336eeba0a3987b0036959d6af8',1,'BasicGaussianProcess']]]
];
