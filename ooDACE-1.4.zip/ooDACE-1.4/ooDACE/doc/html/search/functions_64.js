var searchData=
[
  ['dacefit',['dacefit',['../dacefit_8m.html#ab70279fbd8033a17b41b68346ac7777a',1,'dacefit.m']]],
  ['demo',['demo',['../demo_8m.html#a5a1927cd442e61d4db92b500132c054f',1,'demo.m']]],
  ['display',['display',['../class_basic_gaussian_process.html#a9de56d4c14e5e934fb1cbdbf87dc337f',1,'BasicGaussianProcess']]]
];
