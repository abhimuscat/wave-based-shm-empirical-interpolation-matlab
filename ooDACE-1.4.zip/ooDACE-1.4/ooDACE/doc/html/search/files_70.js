var searchData=
[
  ['plotkrigingmodel_2em',['plotKrigingModel.m',['../plot_kriging_model_8m.html',1,'']]],
  ['plotlikelihood_2em',['plotLikelihood.m',['../plot_likelihood_8m.html',1,'']]],
  ['plotscattereddata_2em',['plotScatteredData.m',['../plot_scattered_data_8m.html',1,'']]],
  ['plotvariogram_2em',['plotVariogram.m',['../plot_variogram_8m.html',1,'']]],
  ['polynomialcoding_2em',['polynomialCoding.m',['../polynomial_coding_8m.html',1,'']]],
  ['posteriorbeta_2em',['posteriorBeta.m',['../posterior_beta_8m.html',1,'']]],
  ['powerbase_2em',['powerBase.m',['../power_base_8m.html',1,'']]],
  ['predict_2em',['predict.m',['../@_kriging_2predict_8m.html',1,'']]],
  ['predict_2em',['predict.m',['../@_basic_gaussian_process_2predict_8m.html',1,'']]],
  ['predict_5fderivatives_2em',['predict_derivatives.m',['../@_basic_gaussian_process_2predict__derivatives_8m.html',1,'']]],
  ['predict_5fderivatives_2em',['predict_derivatives.m',['../@_kriging_2predict__derivatives_8m.html',1,'']]],
  ['predictor_2em',['predictor.m',['../predictor_8m.html',1,'']]],
  ['pseudolikelihood_2em',['pseudoLikelihood.m',['../pseudo_likelihood_8m.html',1,'']]]
];
