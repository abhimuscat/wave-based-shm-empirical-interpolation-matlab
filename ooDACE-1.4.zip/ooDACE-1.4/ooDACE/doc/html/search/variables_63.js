var searchData=
[
  ['c',['C',['../class_basic_gaussian_process.html#ae59e0ac8d0c43c81f50236f719763efc',1,'BasicGaussianProcess']]],
  ['c_5freinterp',['C_reinterp',['../class_basic_gaussian_process.html#a3842b87f75b6b41db2b78d453f98a878',1,'BasicGaussianProcess']]],
  ['correlationfcn',['correlationFcn',['../class_basic_gaussian_process.html#a4bd8b05969772320afb6de2b41ac4bfa',1,'BasicGaussianProcess']]]
];
