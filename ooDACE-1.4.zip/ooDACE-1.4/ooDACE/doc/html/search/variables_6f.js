var searchData=
[
  ['optimidx',['optimIdx',['../class_basic_gaussian_process.html#a3f6f06747a894e644d9659241463651c',1,'BasicGaussianProcess']]],
  ['optimnrparameters',['optimNrParameters',['../class_basic_gaussian_process.html#a0c10d8e65ed04a6dd47b9c8fa1fd40b9',1,'BasicGaussianProcess']]],
  ['options',['options',['../class_basic_gaussian_process.html#a0717e747985fb4e7eb9a3cdc4f1426bf',1,'BasicGaussianProcess']]]
];
